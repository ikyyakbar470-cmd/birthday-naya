from flask import Flask
import os
from urllib.parse import quote

app = Flask(__name__)

def get_photos():
    folder = os.path.join(app.static_folder, "kenangan")
    if not os.path.exists(folder):
        return []
    allowed = (".jpg", ".jpeg", ".png", ".webp")
    return [
        file for file in sorted(os.listdir(folder))
        if file.lower().endswith(allowed)
    ]

@app.route("/")
def home():
    photos = get_photos()
    gallery = ""

    for index, photo in enumerate(photos):
        photo_url = "/static/kenangan/" + quote(photo)
        rotations = [-2, 1.5, -1, 2, -1.5, 1]
        rotation = rotations[index % len(rotations)]

        gallery += f"""
        <div class="memory-card"
             style="--rotation:{rotation}deg"
             onclick="openPhoto('{photo_url}')">
            <div class="tape"></div>
            <img src="{photo_url}" alt="Foto kenangan">
            <div class="photo-caption">💖 Momen indah 💖</div>
        </div>
        """

    if not gallery:
        gallery = """
        <div class="empty">
            📸<br>
            Belum ada foto kenangan ❤️
        </div>
        """

    return f"""
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🎂 Happy 18th Birthday Naya 🎂</title>

<style>
* {{ box-sizing: border-box; }}
html {{ scroll-behavior: smooth; }}

body {{
    margin: 0;
    min-height: 100vh;
    font-family: Arial, Helvetica, sans-serif;
    color: #4b3b32;
    overflow-x: hidden;
    background: #e8d8bd;
}}

body::before {{
    content: "";
    position: fixed;
    inset: 0;
    pointer-events: none;
    opacity: .5;
    background-image: repeating-linear-gradient(
        0deg, transparent, transparent 31px,
        rgba(120,90,60,.13) 32px
    );
    z-index: -2;
}}

.emoji-decoration {{
    position: fixed;
    z-index: 1;
    pointer-events: none;
    font-size: 30px;
    opacity: .8;
    animation: emojiFloat 6s ease-in-out infinite;
}}

@keyframes emojiFloat {{
    0%, 100% {{ transform: translateY(0) rotate(-8deg); }}
    50% {{ transform: translateY(-25px) rotate(8deg); }}
}}

.star {{
    position: fixed;
    width: 6px;
    height: 6px;
    background: white;
    border-radius: 50%;
    opacity: .8;
    animation: twinkle 2s infinite alternate;
    z-index: 1;
}}

@keyframes twinkle {{
    from {{ opacity: .3; transform: scale(.7); }}
    to {{ opacity: 1; transform: scale(1.4); }}
}}

.music-button {{
    position: fixed;
    top: 18px;
    right: 18px;
    z-index: 10000;
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 12px 18px;
    border-radius: 50px;
    border: 2px solid #d5b58a;
    background: #fffaf0;
    color: #76503d;
    font-size: 15px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 5px 20px rgba(0,0,0,.2);
    transition: .3s;
}}

.music-button:hover {{
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,.25);
}}

.music-button.playing {{
    background: #f8e6a8;
    border-color: #b58a48;
}}

.music-icon {{ font-size: 20px; }}
.music-status {{ font-size: 12px; opacity: .8; }}

.container {{
    position: relative;
    z-index: 2;
    max-width: 1050px;
    margin: 35px auto;
    padding: 55px 30px 80px;
    text-align: center;
    background: #fffdf5;
    border-radius: 5px;
    box-shadow: 0 15px 45px rgba(70,45,25,.25);
}}

.container::before {{
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 65px;
    width: 2px;
    background: rgba(210,90,90,.25);
}}

h1 {{
    position: relative;
    font-family: Georgia, "Times New Roman", serif;
    font-size: clamp(40px, 8vw, 78px);
    color: #76503d;
    margin: 10px 0;
    text-shadow: 2px 3px 0 rgba(120,80,50,.12);
    animation: titleAnimation 1.5s ease;
}}

@keyframes titleAnimation {{
    from {{ opacity: 0; transform: translateY(-30px) scale(.9); }}
    to {{ opacity: 1; transform: translateY(0) scale(1); }}
}}

.title-emoji {{
    display: inline-block;
    font-size: 38px;
    margin: 0 6px;
    animation: emojiBounce 1.5s infinite alternate;
}}

@keyframes emojiBounce {{
    from {{ transform: translateY(0) rotate(-5deg); }}
    to {{ transform: translateY(-8px) rotate(5deg); }}
}}

.birthday-emojis {{
    font-size: 30px;
    margin: 10px 0;
    letter-spacing: 7px;
}}

.eighteen {{
    display: inline-block;
    margin: 15px auto 18px;
    padding: 13px 28px;
    color: #6f4936;
    background: #f8e6a8;
    border: 2px dashed #b58a48;
    border-radius: 8px;
    font-family: Georgia, serif;
    font-size: 22px;
    font-weight: bold;
    letter-spacing: 1px;
    box-shadow: 3px 4px 0 rgba(120,80,50,.15);
    transform: rotate(-1deg);
    animation: birthday18 2s ease-in-out infinite alternate;
}}

@keyframes birthday18 {{
    from {{ transform: rotate(-1deg) scale(1); }}
    to {{ transform: rotate(1deg) scale(1.04); }}
}}

.subtitle {{
    font-family: Georgia, serif;
    font-size: 23px;
    color: #80604c;
    margin-bottom: 30px;
}}

.main-photo {{
    width: 280px;
    height: 280px;
    object-fit: cover;
    border-radius: 50%;
    border: 9px solid white;
    box-shadow: 0 10px 25px rgba(80,50,30,.25);
    animation: floating 4s ease-in-out infinite;
    cursor: pointer;
}}

@keyframes floating {{
    0%, 100% {{ transform: translateY(0) rotate(-1deg); }}
    50% {{ transform: translateY(-12px) rotate(1deg); }}
}}

.message {{
    max-width: 750px;
    margin: 45px auto;
    padding: 30px 35px;
    text-align: left;
    background: #fffdf5;
    border-left: 5px solid #d99b7c;
    box-shadow: 0 5px 15px rgba(80,50,30,.12);
    font-family: Georgia, serif;
    font-size: 18px;
    line-height: 1.9;
}}

.message p {{ margin: 15px 0; }}

.normal-button {{
    border: none;
    padding: 14px 28px;
    border-radius: 10px;
    background: #f5dca4;
    color: #694633;
    font-size: 17px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 5px 12px rgba(80,50,30,.2);
    transition: .3s;
}}

.normal-button:hover {{
    transform: translateY(-3px) scale(1.03);
    background: #f1ce83;
}}

#secretMessage {{
    display: none;
    max-width: 700px;
    margin: 25px auto;
    padding: 25px;
    background: #fff8df;
    border: 2px dashed #c69b63;
    box-shadow: 3px 5px 15px rgba(80,50,30,.12);
    font-family: Georgia, serif;
    line-height: 1.8;
    animation: fadeIn .8s;
}}

@keyframes fadeIn {{
    from {{ opacity: 0; transform: translateY(20px); }}
    to {{ opacity: 1; transform: translateY(0); }}
}}

.memory-section {{
    margin-top: 70px;
    padding-top: 40px;
    border-top: 2px dashed rgba(120,80,50,.25);
}}

.memory-section h2 {{
    font-family: Georgia, serif;
    font-size: 34px;
    color: #76503d;
    margin-bottom: 10px;
}}

.memory-description {{
    color: #80604c;
    margin-bottom: 35px;
    font-family: Georgia, serif;
    font-size: 18px;
}}

.gallery {{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 35px 25px;
    padding: 10px;
}}

.memory-card {{
    position: relative;
    min-height: 280px;
    padding: 13px 13px 38px;
    background: #fffef8;
    border: 1px solid #ded6c7;
    box-shadow: 3px 7px 15px rgba(60,40,20,.22);
    cursor: pointer;
    transition: .35s;
    transform: rotate(var(--rotation));
}}

.memory-card:hover {{
    transform: translateY(-8px) rotate(0deg) scale(1.03);
    box-shadow: 5px 15px 25px rgba(60,40,20,.3);
}}

.memory-card img {{
    width: 100%;
    height: 220px;
    object-fit: cover;
    display: block;
}}

.tape {{
    position: absolute;
    top: -13px;
    left: 50%;
    transform: translateX(-50%) rotate(-2deg);
    width: 75px;
    height: 25px;
    background: rgba(224,190,125,.75);
    box-shadow: 0 2px 4px rgba(0,0,0,.1);
    z-index: 3;
}}

.photo-caption {{
    padding-top: 12px;
    font-family: "Comic Sans MS", cursive;
    color: #76503d;
    font-size: 14px;
}}

#photoPopup {{
    position: fixed;
    inset: 0;
    z-index: 99999;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 25px;
    background: rgba(35,25,20,.92);
}}

#popupImage {{
    max-width: 92%;
    max-height: 85vh;
    object-fit: contain;
    background: white;
    padding: 10px;
    box-shadow: 0 15px 60px rgba(0,0,0,.6);
}}

.closePhoto {{
    position: absolute;
    top: 10px;
    right: 25px;
    font-size: 55px;
    color: white;
    cursor: pointer;
    z-index: 5;
}}

.heart {{
    position: fixed;
    bottom: -50px;
    font-size: 25px;
    animation: heartUp 7s linear forwards;
    z-index: 4;
    pointer-events: none;
}}

@keyframes heartUp {{
    from {{
        transform: translateY(0) rotate(0deg);
        opacity: 1;
    }}
    to {{
        transform: translateY(-110vh) rotate(360deg);
        opacity: 0;
    }}
}}

footer {{
    margin-top: 70px;
    padding-top: 25px;
    border-top: 1px dashed #cdbda7;
    color: #80604c;
    font-family: Georgia, serif;
    font-size: 14px;
}}

@media(max-width: 700px) {{
    .container {{
        margin: 15px 10px;
        padding: 40px 18px 60px;
    }}

    .container::before {{ left: 35px; }}

    .gallery {{
        grid-template-columns: repeat(2, 1fr);
        gap: 25px 12px;
    }}

    .memory-card {{
        min-height: 205px;
        padding: 8px 8px 28px;
    }}

    .memory-card img {{ height: 160px; }}

    .main-photo {{
        width: 230px;
        height: 230px;
    }}

    .message {{
        padding: 20px;
        font-size: 16px;
    }}

    .eighteen {{
        font-size: 18px;
        padding: 10px 18px;
    }}

    .subtitle {{ font-size: 19px; }}

    .music-button {{
        top: 10px;
        right: 10px;
        padding: 9px 14px;
        font-size: 13px;
    }}

    .music-status {{ display: none; }}

    .emoji-decoration {{ font-size: 23px; }}
}}

@media(max-width: 450px) {{
    .gallery {{
        grid-template-columns: 1fr 1fr;
        gap: 20px 10px;
    }}

    .memory-card {{ min-height: 180px; }}
    .memory-card img {{ height: 135px; }}
    h1 {{ font-size: 42px; }}

    .birthday-emojis {{
        font-size: 23px;
        letter-spacing: 3px;
    }}
}}
</style>
</head>

<body>

<div class="emoji-decoration" style="top:8%;left:5%;animation-delay:0s;">🎈</div>
<div class="emoji-decoration" style="top:18%;right:7%;animation-delay:1s;">🎁</div>
<div class="emoji-decoration" style="top:35%;left:4%;animation-delay:2s;">💕</div>
<div class="emoji-decoration" style="top:45%;right:4%;animation-delay:1.5s;">✨</div>
<div class="emoji-decoration" style="top:65%;left:6%;animation-delay:3s;">🎀</div>
<div class="emoji-decoration" style="top:75%;right:6%;animation-delay:2.5s;">💖</div>
<div class="emoji-decoration" style="top:88%;left:12%;animation-delay:1s;">🌸</div>
<div class="emoji-decoration" style="top:90%;right:12%;animation-delay:3s;">🥳</div>

<audio id="musik" loop preload="auto">
    <source src="/static/musik/ulangtahun.mp3" type="audio/mpeg">
    Browser kamu tidak mendukung audio.
</audio>

<button id="musicButton" class="music-button" onclick="putarMusik()">
    <span id="musicIcon" class="music-icon">▶️</span>
    <span id="musicText">Putar Musik</span>
    <span id="musicStatus" class="music-status">• OFF</span>
</button>

<div class="star" style="top:10%;left:8%"></div>
<div class="star" style="top:20%;left:85%"></div>
<div class="star" style="top:40%;left:12%"></div>
<div class="star" style="top:60%;left:92%"></div>
<div class="star" style="top:75%;left:10%"></div>
<div class="star" style="top:85%;left:80%"></div>

<div class="container">

<div class="birthday-emojis">
    🎂 🎈 🎉 ✨ 🎁 💖
</div>

<h1>
    <span class="title-emoji">🎉</span>
    Happy Birthday NAYA
    <span class="title-emoji">🎉</span>
</h1>

<div class="eighteen">
    🎂 ✨ HAPPY 18TH BIRTHDAY ✨ 🎂
</div>

<div class="subtitle">
    💕 🎀 Untuk NAYA 🎀 💕
</div>

<img
    class="main-photo"
    src="/static/kenangan/foto%20hbd%202.jpeg"
    alt="Foto Naya"
    onclick="openPhoto(this.src)"
>

<div class="message">
    <p>🎂 Hari ini bukan hari biasa...</p>

    <p>
        🎉 Karena hari ini adalah hari spesial
        seseorang yang luar biasa. 💖
    </p>

    <p>
        🥳 Selamat memasuki usia 18 tahun,
        Naya! 🎈
    </p>

    <p>
        ✨ Semoga di umur yang baru ini,
        semua hal baik datang satu per satu. 🌸
    </p>

    <p>
        💕 Semoga selalu diberikan kesehatan,
        kebahagiaan, dan banyak alasan
        untuk tersenyum. 😊
    </p>

    <p>
        🎁 Semoga semua impian dan harapanmu
        bisa tercapai satu per satu. ✨
    </p>

    <p>❤️ Selamat ulang tahun, Naya! ❤️</p>
</div>

<button class="normal-button" onclick="showMessage()">
    💌 Buka Pesan Rahasia
</button>

<div id="secretMessage">

    <h2>💌 Pesan Khusus Untuk Naya 💖</h2>

    <p>🎂 Selamat ulang tahun yang ke-18!</p>

    <p>
        🥳 Semoga di usia yang baru ini
        kamu mendapatkan banyak kebahagiaan,
        pengalaman baru, dan cerita indah. ✨
    </p>

    <p>
        🌸 Semoga semua impian yang kamu punya
        bisa tercapai satu per satu.
    </p>

    <p>
        💕 Jangan lupa untuk selalu tersenyum,
        menikmati setiap momen,
        dan menghargai setiap perjalananmu.
    </p>

    <p>
        🎁 Semoga hari ini menjadi salah satu
        hari yang paling berkesan.
    </p>

    <h2>🎉🎂 HAPPY 18TH BIRTHDAY NAYA! 🎂🎉</h2>

    <p>💖 🎀 ✨ 🥳 🎈 🎁 🌸</p>

</div>

<div class="memory-section">

    <h2>
        📸 Foto-Foto Kenangan 💖
    </h2>

    <p class="memory-description">
        📖 Beberapa momen yang sayang
        untuk dilupakan... 🥹❤️
    </p>

    <div class="gallery">
        {gallery}
    </div>

</div>

<footer>
    🎀 Dibuat dengan ❤️ untuk Naya 🎀
</footer>

</div>

<div id="photoPopup" onclick="closePhoto()">
    <span class="closePhoto">×</span>

    <img
        id="popupImage"
        src=""
        alt="Foto"
        onclick="event.stopPropagation()"
    >
</div>

<script>
const musik = document.getElementById("musik");
const musicButton = document.getElementById("musicButton");
const musicIcon = document.getElementById("musicIcon");
const musicText = document.getElementById("musicText");
const musicStatus = document.getElementById("musicStatus");

function updateMusicButton() {{
    if (musik.paused) {{
        musicIcon.innerHTML = "▶️";
        musicText.innerHTML = "Putar Musik";
        musicStatus.innerHTML = "• OFF";
        musicButton.classList.remove("playing");
    }} else {{
        musicIcon.innerHTML = "⏸️";
        musicText.innerHTML = "Matikan Musik";
        musicStatus.innerHTML = "• ON";
        musicButton.classList.add("playing");
    }}
}}

function putarMusik() {{
    if (musik.paused) {{
        musik.play()
        .then(function() {{
            updateMusicButton();
        }})
        .catch(function(error) {{
            console.log("Audio error:", error);
            alert(
                "Musik tidak dapat diputar. Pastikan file 'ulangtahun.mp3' ada di folder static/musik."
            );
        }});
    }} else {{
        musik.pause();
        updateMusicButton();
    }}
}}

musik.addEventListener("play", updateMusicButton);
musik.addEventListener("pause", updateMusicButton);
musik.addEventListener("ended", updateMusicButton);

function showMessage() {{
    const message = document.getElementById("secretMessage");

    if (message.style.display === "block") {{
        message.style.display = "none";
    }} else {{
        message.style.display = "block";
        createHearts();
    }}
}}

function openPhoto(src) {{
    const popup = document.getElementById("photoPopup");
    const image = document.getElementById("popupImage");

    image.src = src;
    popup.style.display = "flex";
}}

function closePhoto() {{
    document.getElementById("photoPopup").style.display = "none";
}}

function createHeart() {{
    const heart = document.createElement("div");
    heart.className = "heart";

    const hearts = [
        "❤️", "💕", "💗", "💖",
        "💝", "🎀", "✨", "🌸"
    ];

    heart.innerHTML =
        hearts[Math.floor(Math.random() * hearts.length)];

    heart.style.left =
        Math.random() * 100 + "%";

    heart.style.fontSize =
        (15 + Math.random() * 25) + "px";

    heart.style.animationDuration =
        (5 + Math.random() * 4) + "s";

    document.body.appendChild(heart);

    setTimeout(function() {{
        heart.remove();
    }}, 9000);
}}

function createHearts() {{
    for (let i = 0; i < 15; i++) {{
        setTimeout(createHeart, i * 120);
    }}
}}

setInterval(createHeart, 1800);
updateMusicButton();
</script>

</body>
</html>
"""

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )
