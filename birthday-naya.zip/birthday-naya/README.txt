# Birthday Naya

Project Flask untuk website ucapan ulang tahun ke-18.

## Struktur
- app.py
- requirements.txt
- Procfile
- static/musik/ulangtahun.mp3
- static/kenangan/

## Menjalankan di komputer
```bash
pip install -r requirements.txt
python app.py
```

Buka:
http://127.0.0.1:5000

## Catatan
Tambahkan foto kenangan ke folder `static/kenangan/`.
Foto utama yang digunakan adalah `foto hbd 2.jpeg`.
Tambahkan musik dengan nama `ulangtahun.mp3` ke `static/musik/`.
